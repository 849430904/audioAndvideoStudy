package com.dongnaoedu.dnffmpegplayer;

import java.io.File;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void mDecode(View btn){
		String input = new File(Environment.getExternalStorageDirectory(),"input.mp4").getAbsolutePath();
		String output = new File(Environment.getExternalStorageDirectory(),"output_1280x720_yuv420p.yuv").getAbsolutePath();
		VideoUtils.decode(input, output);
	}
}
